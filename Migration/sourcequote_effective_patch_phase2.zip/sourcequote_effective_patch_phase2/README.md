# SourceQuote effective patch — phase 2

This folder contains the **second effective content patch** for SourceQuote densification.

Files:
- `PATCH_SOURCEQUOTE_EFFECTIVE_PHASE2.json` — the patch payload itself
- `PATCH_SCOPE.md` — what this patch covers
- `APPLY_WITH_AGENT.md` — minimal implementation instructions
- `PATCH_SOURCEQUOTE_EFFECTIVE_PHASE2.csv` — flat table view

This phase covers the next structurally weak sections after phase 1:
- `II.2`
- `II.3`
- `II.3.2`
- `III.2`
- `III.3.3`

The quotes have already been selected and paginated from the thesis PDF.
