# SourceQuote effective patch — phase 3

This folder contains the **third effective content patch** for SourceQuote densification.

Files:
- `PATCH_SOURCEQUOTE_EFFECTIVE_PHASE3.json` — the patch payload itself
- `PATCH_SCOPE.md` — what this patch covers
- `APPLY_WITH_AGENT.md` — minimal implementation instructions
- `PATCH_SOURCEQUOTE_EFFECTIVE_PHASE3.csv` — flat table view

This phase covers:
- chapter I strategic infrastructure sections (`I.2`, `I.2.1`, `I.2.2`, `I.3.2`, `I.3.3`)
- conclusion blocks used by thesis-reader / story mode

The quotes have already been selected and paginated from the thesis PDF.

This phase also introduces a **tighter quote-to-entity hierarchy**:
- `primary_entity_names`
- `secondary_entity_names`
- `bridge_entity_names`

So the implementation agent no longer treats every semantic support as equivalent.
