# Patch scope — SourceQuote effective patch (phase 3)

This patch is the **actual densification payload** for chapter I and the general conclusion.

## What it covers
- `I.2`
- `I.2.1`
- phase-level chapter I anchors (`preuve de concept`, `péché`, `maturation`)
- `I.2.2` on reintermediation and transaction regulations
- `I.3.2`
- `I.3.3`
- conclusion blocks on infrastructure, crisis sociology, and rule/discretion

## Strategy
- strengthen the sections that are the most reusable for scrollytelling and story mode
- add short, paginated quotes that state the argument clearly
- tighten semantic attachment with a hierarchy:
  - primary entity = principal anchor
  - secondary entities = close conceptual support
  - bridge entities = optional connectors for graph traversal

## Result expected after implementation
- chapter I becomes much more usable as an infrastructure-driven reader layer
- the Bitcoin three-phase development can be anchored quote-by-quote
- Ethereum’s rupture with Bitcoin is no longer citation-thin
- the conclusion gains reusable thesis-level quotes for story mode and graph-reader
- the rule/discretion closure is explicitly anchored

## Important
This is not an audit. It is a **content-complete patch payload** for an implementation agent.
