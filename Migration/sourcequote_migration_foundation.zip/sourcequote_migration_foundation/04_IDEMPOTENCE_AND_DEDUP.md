# Idempotence and deduplication rules

## Règle 1 — clé primaire logique
La clé idempotente principale est `seed_id`.

Si une SourceQuote avec le même `seed_id` existe déjà :
- ne pas créer un doublon
- mettre à jour seulement les champs manquants ou compléter les liens absents

## Règle 2 — signature secondaire de sécurité
Construire une signature de secours :
`normalize(quoteText) + '::' + page + '::' + firstTargetSectionKey`

Utilité :
- détecter les doublons accidentels même si un `seed_id` a changé

## Règle 3 — déduplication des liens
Avant de créer un lien :
- vérifier si la relation existe déjà entre les deux IDs
- pour les liens de support, tenir compte du `support_level` s'il est stocké

## Règle 4 — mise à jour non destructive
Ne jamais écraser :
- `primary_entity_names`
- `secondary_entity_names`
- `bridge_entity_names`
par une simple liste plate issue d'une phase antérieure.

## Règle 5 — traçabilité
Chaque opération doit laisser une trace :
- créée
- enrichie
- ignorée car déjà présente
- partiellement appliquée

## Règle 6 — hiérarchie préservée
Quand phase 3 apporte une hiérarchie plus fine pour une citation équivalente :
- conserver la hiérarchie de phase 3 comme version autoritative
- ne pas la rabattre vers `quote_supports_entity_names` seul
