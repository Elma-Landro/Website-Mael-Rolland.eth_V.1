# Applier behavior for `ADD_SOURCEQUOTE_WITH_SECTION_LINKS`

## Input
Une opération normalisée contenant au minimum :
- `seed_id`
- `title`
- `quoteText`
- `page`
- `targetSections[]`

## Effet attendu
1. créer ou retrouver une entité `SourceQuote`
2. lui attacher les attributs de citation
3. créer les liens vers les sections ciblées
4. créer les liens de support vers les entités du graphe
5. produire un résultat journalisé

## Attributs minimaux de l'entité SourceQuote
- `seed_id`
- `title`
- `quoteText`
- `page`
- `source_phase`
- `rationale` si présent

## Liens sectionnels
Pour chaque item de `targetSections` :
- résoudre `section_key`
- créer relation `appears in section`
- ne pas dédupliquer à l'aveugle par seul `section_name`
- si `section_key` est introuvable : logguer en erreur bloquante pour cette cible mais pas pour l'ensemble de l'opération

## Liens de support
Ordre de tentative :
1. `primary_entity_names`
2. `secondary_entity_names`
3. `bridge_entity_names`
4. si hiérarchie absente : `quote_supports_entity_names`

Comportement :
- relation par défaut : `quote supports`
- si le graphe permet des sous-types ou attributs de relation, ajouter `support_level = primary|secondary|bridge`
- si ce n'est pas possible, conserver au minimum cette hiérarchie dans les attributs de l'entité SourceQuote

## Résolution des noms d'entités
Stratégie :
1. match exact
2. match normalisé (casse / accents)
3. alias connu si mapping local existe
4. sinon : `unresolved_support_name`

Ne jamais relier une citation à une entité ambiguë sans le logguer explicitement.

## Sortie de l'applier
Pour chaque opération :
- `seed_id`
- `status = created|updated|skipped|partial`
- `sourcequote_entity_id`
- `sections_linked[]`
- `supports_linked[]`
- `unresolved_sections[]`
- `unresolved_supports[]`
