# SourceQuote Migration Foundation Pack

Ce pack ne remplace pas les patches de contenu phases 1-3.
Il sert à rendre leur application sûre et cohérente dans le repo.

Il répond aux 5 points remontés par le QA statique :
1. normalisation de schéma entre phases 1 / 2 / 3
2. orchestrateur explicite Phase1 -> Phase2 -> Phase3
3. définition de l'applier `ADD_SOURCEQUOTE_WITH_SECTION_LINKS`
4. idempotence et déduplication
5. préservation de la hiérarchie `primary / secondary / bridge`

Ordre d'usage conseillé :
- 00_VERDICT.md
- 01_UNIFIED_NORMALIZATION_SPEC.json
- 02_APPLIER_BEHAVIOR.md
- 03_ORCHESTRATION_PLAN.md
- 04_IDEMPOTENCE_AND_DEDUP.md
- 05_AGENT_IMPLEMENTATION_PROMPT.md
