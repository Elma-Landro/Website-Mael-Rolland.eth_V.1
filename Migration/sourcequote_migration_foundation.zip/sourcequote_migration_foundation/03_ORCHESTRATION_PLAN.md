# Orchestration plan

## Principe
Toujours appliquer dans cet ordre :
1. Phase 1
2. Phase 2
3. Phase 3

## Pourquoi
- phase 1 comble les zéros les plus critiques
- phase 2 densifie le coeur théorique et empirique
- phase 3 introduit la hiérarchie primaire / secondaire / bridge

## Entrées attendues
- `PATCH_SOURCEQUOTE_EFFECTIVE_PHASE1.json`
- `PATCH_SOURCEQUOTE_EFFECTIVE_PHASE2.json`
- `PATCH_SOURCEQUOTE_EFFECTIVE_PHASE3.json`

## Orchestrateur logique
1. charger les 3 fichiers
2. normaliser chaque opération
3. annoter `source_phase`
4. concaténer en liste ordonnée
5. contrôler les `seed_id` dupliqués avant import
6. appliquer opération par opération
7. produire un rapport consolidé

## Rapport consolidé attendu
- nombre d'opérations lues
- nombre d'opérations normalisées
- créées
- mises à jour
- ignorées (idempotence)
- partiellement appliquées
- supports ambigus
- sections introuvables

## Point d'entrée unique recommandé
Créer un fichier d'orchestration du type :
- `Migration/APPLY_SOURCEQUOTE_PHASES.md` pour la doc
- et/ou `scripts/apply-sourcequote-phases.mjs` pour l'exécution

Le fichier racine ne doit plus pointer seulement la phase 2.
