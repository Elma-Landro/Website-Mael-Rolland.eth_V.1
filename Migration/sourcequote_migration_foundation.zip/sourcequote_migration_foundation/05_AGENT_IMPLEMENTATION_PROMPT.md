# Agent implementation prompt

Tu dois implémenter la couche de migration SourceQuote manquante pour consommer correctement les patches `PATCH_SOURCEQUOTE_EFFECTIVE_PHASE1/2/3.json`.

But :
- ne pas toucher au fond citationnel
- créer une couche d'ingestion sûre et idempotente
- préserver la hiérarchie `primary / secondary / bridge`

À faire :
1. créer un normalizer multi-phases
2. créer un orchestrateur explicite Phase1 -> Phase2 -> Phase3
3. implémenter l'applier de `ADD_SOURCEQUOTE_WITH_SECTION_LINKS`
4. garantir l'idempotence avec `seed_id` + signature secondaire
5. produire un rapport final d'import

Lis et applique dans cet ordre :
- `01_UNIFIED_NORMALIZATION_SPEC.json`
- `02_APPLIER_BEHAVIOR.md`
- `03_ORCHESTRATION_PLAN.md`
- `04_IDEMPOTENCE_AND_DEDUP.md`

Contraintes :
- ne jamais aplatir la hiérarchie phase 3
- ne jamais créer de doublons si relance
- ne jamais relier automatiquement une citation à une entité ambiguë sans warning
- ne pas modifier le contenu textuel des citations
- ne pas ignorer phase 1 ou phase 3 sous prétexte que le point d'entrée actuel mentionne phase 2

Livrables :
- fichiers modifiés
- description du normalizer
- description de l'applier
- rapport d'exécution ou rapport simulé
- points ambigus restants
